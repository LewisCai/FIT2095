//Sale object class with name as string , price as number , quantity as number and isPaid as boolean
class Sale {
    constructor(name, price, quantity, isPaid) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.isPaid = isPaid;
    }
}

